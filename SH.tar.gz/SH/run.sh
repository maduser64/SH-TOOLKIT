#!/bin/sh

cd /opt/SH
python /opt/SH/SH.py

_________ ___ ___   ___________________   ________  .____       ____  __.______________
/   _____//   |   \  \__    ___/\_____  \  \_____  \ |    |     |    |/ _|   \__    ___/
\_____  \/    ~    \   |    |    /   |   \  /   |   \|    |     |      < |   | |    |
/        \    Y    /   |    |   /    |    \/    |    \    |___  |    |  \|   | |    |
/_______  /\___|_  /    |____|   \_______  /\_______  /_______ \ |____|__ \___| |____|
      \/       \/                      \/         \/        \/         \/                      ReadMe
---------------------------------------------------------------------------------
Name: SH ToolKit
Author: BL4CKvGHOST (LEADER)
Contact Info: bl4ckvghost@torbox3uiot6wchz.onion
---------------------------------------------------------------------------------
Unless your smart enough to fix it, don't change any of the files and than ask
me to help you if it screws up, I wont.
---------------------------------------------------------------------------------
Bugs, problems or anything I should know of? Let me know and direct message me on My Email
at BL4CKvGHOST.
If errors occur, try restarting SH ToolKit. Still not working? Contact me above. ^^
---------------------------------------------------------------------------------
If your gonna use some of my source, please ask me and give credits pls :)
Don't wanna get exposed? Give creds :/
I AM NOT RESPONSIBLE FOR WHAT YOU DO WITH THIS PROGRAM. SH ToolKit WAS MADE PURELY FOR GOOD.
---------------------------------------------------------------------------------
You might need:
- An Internet connection
- Dictionary attack list
- Phone/Email
- Linux is a must-have
---------------------------------------------------------------------------------
Follow Me On GitHub For More Updates
contact me on torbox
--------------------------------------------------------------------------------
                            ** Made In Egypt **
--------------------------------------------------------------------------------
Security Not Hacking
Security No More
Security Is Not A Crime It Is An Art!
# BL4CKvGHOST
